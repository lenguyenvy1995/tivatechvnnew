/******/ (() => { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ "./platform/core/base/resources/sass/components/crop-image.scss":
/*!**********************************************************************!*\
  !*** ./platform/core/base/resources/sass/components/crop-image.scss ***!
  \**********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/core/base/resources/sass/components/error-pages.scss":
/*!***********************************************************************!*\
  !*** ./platform/core/base/resources/sass/components/error-pages.scss ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/core/base/resources/sass/components/tree-category.scss":
/*!*************************************************************************!*\
  !*** ./platform/core/base/resources/sass/components/tree-category.scss ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/core/base/resources/sass/core.scss":
/*!*****************************************************!*\
  !*** ./platform/core/base/resources/sass/core.scss ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/core/base/resources/sass/libraries/select2/select2.scss":
/*!**************************************************************************!*\
  !*** ./platform/core/base/resources/sass/libraries/select2/select2.scss ***!
  \**************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/core/media/resources/sass/media.scss":
/*!*******************************************************!*\
  !*** ./platform/core/media/resources/sass/media.scss ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/core/setting/resources/sass/admin-email.scss":
/*!***************************************************************!*\
  !*** ./platform/core/setting/resources/sass/admin-email.scss ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/core/table/resources/sass/table.scss":
/*!*******************************************************!*\
  !*** ./platform/core/table/resources/sass/table.scss ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/packages/get-started/resources/sass/get-started.scss":
/*!***********************************************************************!*\
  !*** ./platform/packages/get-started/resources/sass/get-started.scss ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/packages/installer/resources/sass/style.scss":
/*!***************************************************************!*\
  !*** ./platform/packages/installer/resources/sass/style.scss ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/packages/menu/resources/sass/menu.scss":
/*!*********************************************************!*\
  !*** ./platform/packages/menu/resources/sass/menu.scss ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/packages/revision/resources/sass/revision.scss":
/*!*****************************************************************!*\
  !*** ./platform/packages/revision/resources/sass/revision.scss ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/packages/seo-helper/resources/sass/seo-helper.scss":
/*!*********************************************************************!*\
  !*** ./platform/packages/seo-helper/resources/sass/seo-helper.scss ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/packages/shortcode/resources/sass/shortcode.scss":
/*!*******************************************************************!*\
  !*** ./platform/packages/shortcode/resources/sass/shortcode.scss ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/packages/slug/resources/sass/slug.scss":
/*!*********************************************************!*\
  !*** ./platform/packages/slug/resources/sass/slug.scss ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/packages/theme/resources/sass/admin-bar.scss":
/*!***************************************************************!*\
  !*** ./platform/packages/theme/resources/sass/admin-bar.scss ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/packages/theme/resources/sass/guideline.scss":
/*!***************************************************************!*\
  !*** ./platform/packages/theme/resources/sass/guideline.scss ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/packages/theme/resources/sass/theme-options.scss":
/*!*******************************************************************!*\
  !*** ./platform/packages/theme/resources/sass/theme-options.scss ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/packages/widget/resources/sass/widget.scss":
/*!*************************************************************!*\
  !*** ./platform/packages/widget/resources/sass/widget.scss ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/plugins/announcement/resources/sass/announcement.scss":
/*!************************************************************************!*\
  !*** ./platform/plugins/announcement/resources/sass/announcement.scss ***!
  \************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/plugins/backup/resources/sass/backup.scss":
/*!************************************************************!*\
  !*** ./platform/plugins/backup/resources/sass/backup.scss ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/plugins/contact/resources/sass/contact-public.scss":
/*!*********************************************************************!*\
  !*** ./platform/plugins/contact/resources/sass/contact-public.scss ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/plugins/contact/resources/sass/contact.scss":
/*!**************************************************************!*\
  !*** ./platform/plugins/contact/resources/sass/contact.scss ***!
  \**************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/plugins/ecommerce/resources/sass/currencies.scss":
/*!*******************************************************************!*\
  !*** ./platform/plugins/ecommerce/resources/sass/currencies.scss ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/plugins/ecommerce/resources/sass/customer.scss":
/*!*****************************************************************!*\
  !*** ./platform/plugins/ecommerce/resources/sass/customer.scss ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/plugins/ecommerce/resources/sass/ecommerce-product-attributes.scss":
/*!*************************************************************************************!*\
  !*** ./platform/plugins/ecommerce/resources/sass/ecommerce-product-attributes.scss ***!
  \*************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/plugins/ecommerce/resources/sass/ecommerce.scss":
/*!******************************************************************!*\
  !*** ./platform/plugins/ecommerce/resources/sass/ecommerce.scss ***!
  \******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/plugins/ecommerce/resources/sass/front-auth.scss":
/*!*******************************************************************!*\
  !*** ./platform/plugins/ecommerce/resources/sass/front-auth.scss ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/plugins/ecommerce/resources/sass/front-ecommerce-missing-bootstrap.scss":
/*!******************************************************************************************!*\
  !*** ./platform/plugins/ecommerce/resources/sass/front-ecommerce-missing-bootstrap.scss ***!
  \******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/plugins/ecommerce/resources/sass/front-ecommerce-rtl.scss":
/*!****************************************************************************!*\
  !*** ./platform/plugins/ecommerce/resources/sass/front-ecommerce-rtl.scss ***!
  \****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/plugins/ecommerce/resources/sass/front-ecommerce.scss":
/*!************************************************************************!*\
  !*** ./platform/plugins/ecommerce/resources/sass/front-ecommerce.scss ***!
  \************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/plugins/ecommerce/resources/sass/front-faq.scss":
/*!******************************************************************!*\
  !*** ./platform/plugins/ecommerce/resources/sass/front-faq.scss ***!
  \******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/plugins/ecommerce/resources/sass/front-review.scss":
/*!*********************************************************************!*\
  !*** ./platform/plugins/ecommerce/resources/sass/front-review.scss ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/plugins/ecommerce/resources/sass/front-theme-rtl.scss":
/*!************************************************************************!*\
  !*** ./platform/plugins/ecommerce/resources/sass/front-theme-rtl.scss ***!
  \************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/plugins/ecommerce/resources/sass/front-theme.scss":
/*!********************************************************************!*\
  !*** ./platform/plugins/ecommerce/resources/sass/front-theme.scss ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/plugins/ecommerce/resources/sass/order-return.scss":
/*!*********************************************************************!*\
  !*** ./platform/plugins/ecommerce/resources/sass/order-return.scss ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/plugins/ecommerce/resources/sass/report.scss":
/*!***************************************************************!*\
  !*** ./platform/plugins/ecommerce/resources/sass/report.scss ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/plugins/ecommerce/resources/sass/review.scss":
/*!***************************************************************!*\
  !*** ./platform/plugins/ecommerce/resources/sass/review.scss ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/plugins/ecommerce/resources/sass/widget.scss":
/*!***************************************************************!*\
  !*** ./platform/plugins/ecommerce/resources/sass/widget.scss ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/plugins/faq/resources/sass/faq.scss":
/*!******************************************************!*\
  !*** ./platform/plugins/faq/resources/sass/faq.scss ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/plugins/fob-comment/resources/sass/comment.scss":
/*!******************************************************************!*\
  !*** ./platform/plugins/fob-comment/resources/sass/comment.scss ***!
  \******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/plugins/fob-floating-buttons/resources/sass/fob-floating-buttons.scss":
/*!****************************************************************************************!*\
  !*** ./platform/plugins/fob-floating-buttons/resources/sass/fob-floating-buttons.scss ***!
  \****************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/plugins/gallery/resources/sass/admin-gallery.scss":
/*!********************************************************************!*\
  !*** ./platform/plugins/gallery/resources/sass/admin-gallery.scss ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/plugins/gallery/resources/sass/gallery.scss":
/*!**************************************************************!*\
  !*** ./platform/plugins/gallery/resources/sass/gallery.scss ***!
  \**************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/plugins/gallery/resources/sass/object-gallery.scss":
/*!*********************************************************************!*\
  !*** ./platform/plugins/gallery/resources/sass/object-gallery.scss ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/plugins/language/resources/sass/language-public.scss":
/*!***********************************************************************!*\
  !*** ./platform/plugins/language/resources/sass/language-public.scss ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/plugins/language/resources/sass/language.scss":
/*!****************************************************************!*\
  !*** ./platform/plugins/language/resources/sass/language.scss ***!
  \****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/plugins/newsletter/resources/sass/newsletter.scss":
/*!********************************************************************!*\
  !*** ./platform/plugins/newsletter/resources/sass/newsletter.scss ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/plugins/payment/resources/sass/payment-setting.scss":
/*!**********************************************************************!*\
  !*** ./platform/plugins/payment/resources/sass/payment-setting.scss ***!
  \**********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/plugins/payment/resources/sass/payment.scss":
/*!**************************************************************!*\
  !*** ./platform/plugins/payment/resources/sass/payment.scss ***!
  \**************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/plugins/simple-slider/resources/sass/simple-slider.scss":
/*!**************************************************************************!*\
  !*** ./platform/plugins/simple-slider/resources/sass/simple-slider.scss ***!
  \**************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/plugins/social-login/resources/sass/social-login.scss":
/*!************************************************************************!*\
  !*** ./platform/plugins/social-login/resources/sass/social-login.scss ***!
  \************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/plugins/table-details-control/resources/sass/table.scss":
/*!**************************************************************************!*\
  !*** ./platform/plugins/table-details-control/resources/sass/table.scss ***!
  \**************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/plugins/toc/resources/assets/sass/toc.scss":
/*!*************************************************************!*\
  !*** ./platform/plugins/toc/resources/assets/sass/toc.scss ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/plugins/translation/resources/sass/translation.scss":
/*!**********************************************************************!*\
  !*** ./platform/plugins/translation/resources/sass/translation.scss ***!
  \**********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/themes/apexa/assets/js/main.js":
/*!*************************************************!*\
  !*** ./platform/themes/apexa/assets/js/main.js ***!
  \*************************************************/
/***/ (() => {

(function ($) {
  "use strict";

  $.ajaxSetup({
    headers: {
      "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr("content")
    }
  });

  /*=============================================
      =    		 Preloader			      =
  =============================================*/
  function preloader() {
    $("#preloader").delay(0).fadeOut();
  }
  $(window).on("load", function () {
    preloader();
    wowAnimation();
    aosAnimation();
    tg_title_animation();
  });

  /*===========================================
      =    		Mobile Menu			      =
  =============================================*/
  //SubMenu Dropdown Toggle
  if ($(".tgmenu__wrap li.menu-item-has-children ul").length) {
    $(".tgmenu__wrap .navigation li.menu-item-has-children").append('<div class="dropdown-btn"><span class="plus-line"></span></div>');
  }

  //Mobile Nav Hide Show
  if ($(".tgmobile__menu").length) {
    var mobileMenuContent = $(".tgmenu__wrap .tgmenu__main-menu").html();
    $(".tgmobile__menu .tgmobile__menu-box .tgmobile__menu-outer").append(mobileMenuContent);

    //Dropdown Button
    $(".tgmobile__menu li.menu-item-has-children .dropdown-btn").on("click", function () {
      $(this).toggleClass("open");
      $(this).prev("ul").slideToggle(300);
    });
    //Menu Toggle Btn
    $(".mobile-nav-toggler").on("click", function () {
      $("body").addClass("mobile-menu-visible");
    });

    //Menu Toggle Btn
    $(".tgmobile__menu-backdrop, .tgmobile__menu .close-btn").on("click", function () {
      $("body").removeClass("mobile-menu-visible");
    });
  }

  /*=============================================
      =           Data Background             =
  =============================================*/
  $("[data-background]").each(function () {
    $(this).css("background-image", "url(" + $(this).attr("data-background") + ")");
  });

  /*===========================================
      =     Menu sticky & Scroll to top      =
  =============================================*/
  $(window).on("scroll", function () {
    var scroll = $(window).scrollTop();
    if (scroll < 245) {
      $("#sticky-header").removeClass("sticky-menu");
      $(".scroll-to-target").removeClass("open");
      $("#header-fixed-height").removeClass("active-height");
    } else {
      $("#sticky-header").addClass("sticky-menu");
      $(".scroll-to-target").addClass("open");
      $("#header-fixed-height").addClass("active-height");
    }
  });

  /*=============================================
      =    		 Scroll Up  	         =
  =============================================*/
  if ($(".scroll-to-target").length) {
    $(".scroll-to-target").on("click", function (e) {
      e.preventDefault();
      var target = $(this).attr("data-target");
      // animate
      $("html, body").animate({
        scrollTop: $(target).offset().top
      }, 1000);
    });
  }

  /*=============================================
      =            Header Search            =
  =============================================*/
  $(".search-open-btn").on("click", function () {
    $(".search__popup").addClass("search-opened");
    $(".search-popup-overlay").addClass("search-popup-overlay-open");
  });
  $(".search-close-btn").on("click", function () {
    $(".search__popup").removeClass("search-opened");
    $(".search-popup-overlay").removeClass("search-popup-overlay-open");
  });

  /*=============================================
  =     Offcanvas Menu      =
  =============================================*/
  $(".menu-tigger").on("click", function () {
    $(".offCanvas__info, .offCanvas__overly").addClass("active");
    return false;
  });
  $(".menu-close, .offCanvas__overly").on("click", function () {
    $(".offCanvas__info, .offCanvas__overly").removeClass("active");
  });

  /*=============================================
      =          brand active              =
  =============================================*/
  function initBrandsSwiper() {
    var swiper2 = new Swiper(".slider__active", {
      spaceBetween: 0,
      effect: "fade",
      loop: true,
      autoplay: {
        delay: 6000
      }
    });
    var swiper4 = new Swiper(".slider_partners__active", {
      spaceBetween: 0,
      slidesPerView: "auto",
      // effect: "fade",
      loop: true,
      autoplay: {
        delay: 6000
      },
      // Navigation arrows
      navigation: {
        nextEl: ".button-swiper-next",
        prevEl: ".button-swiper-prev"
      }
    });
    var slider = new Swiper(".brand-active", {
      slidesPerView: 1,
      spaceBetween: 30,
      loop: true,
      breakpoints: {
        1200: {
          slidesPerView: 6
        },
        992: {
          slidesPerView: 5
        },
        768: {
          slidesPerView: 4
        },
        576: {
          slidesPerView: 3
        },
        0: {
          slidesPerView: 2
        }
      }
    });
  }
  initBrandsSwiper();

  /*=============================================
      =          project active              =
  =============================================*/
  function initProjectsSwiper() {
    new Swiper(".project-active", {
      spaceBetween: 0,
      loop: true,
      autoplay: {
        delay: 6000
      },
      // Navigation arrows
      navigation: {
        nextEl: ".project-button-next",
        prevEl: ".project-button-prev"
      }
    });
    new Swiper(".project-active-two", {
      slidesPerView: 1,
      spaceBetween: 5,
      loop: true,
      breakpoints: {
        1200: {
          slidesPerView: 4
        },
        992: {
          slidesPerView: 3
        },
        768: {
          slidesPerView: 2
        },
        576: {
          slidesPerView: 2
        },
        0: {
          slidesPerView: 1
        }
      }
    });
  }
  initProjectsSwiper();

  /*=============================================
      =          testimonial active              =
  =============================================*/
  function initTestimonialSwiper() {
    var swiper = new Swiper(".testimonial-nav", {
      spaceBetween: 0,
      slidesPerView: 4
    });
    var swiper2 = new Swiper(".testimonial-active", {
      spaceBetween: 0,
      loop: true,
      autoplay: {
        delay: 6000
      },
      thumbs: {
        swiper: swiper
      },
      // And if we need scrollbar
      scrollbar: {
        el: ".swiper-scrollbar",
        draggable: !0
      }
    });
    var swiper3 = new Swiper(".testimonial-active-two", {
      spaceBetween: 0,
      loop: true,
      slidesPerView: 1,
      autoplay: {
        delay: 6000
      },
      // Navigation arrows
      navigation: {
        nextEl: ".testimonial-button-next",
        prevEl: ".testimonial-button-prev"
      }
    });
    var swiper = new Swiper(".testimonial__nav-three", {
      spaceBetween: 0,
      slidesPerView: 4
    });
    var swiper2 = new Swiper(".testimonial-active-three", {
      spaceBetween: 0,
      loop: true,
      autoplay: {
        delay: 6000
      },
      thumbs: {
        swiper: swiper
      },
      // Navigation arrows
      navigation: {
        nextEl: ".testimonial-two-button-next",
        prevEl: ".testimonial-two-button-prev"
      }
    });
    new Swiper(".testiminials-active", {
      slidesPerView: 3,
      spaceBetween: 24,
      loop: true,
      breakpoints: {
        1200: {
          slidesPerView: 3
        },
        992: {
          slidesPerView: 3
        },
        768: {
          slidesPerView: 2
        },
        576: {
          slidesPerView: 1
        },
        0: {
          slidesPerView: 1
        }
      }
    });
    new Swiper(".testiminials-active-2", {
      slidesPerView: 2,
      spaceBetween: 24,
      loop: true,
      navigation: {
        nextEl: ".button-swiper-testimonial-next",
        prevEl: ".button-swiper-testimonial-prev"
      },
      breakpoints: {
        1200: {
          slidesPerView: 2
        },
        992: {
          slidesPerView: 2
        },
        768: {
          slidesPerView: 1
        },
        576: {
          slidesPerView: 1
        },
        0: {
          slidesPerView: 1
        }
      }
    });
    new Swiper(".slider_baner__active", {
      spaceBetween: 0,
      // effect: "fade",
      loop: true,
      autoplay: {
        delay: 6000
      },
      // Navigation arrows
      navigation: {
        nextEl: ".button-swiper-next",
        prevEl: ".button-swiper-prev"
      },
      pagination: {
        el: ".swiper-pagination-testimonials",
        clickable: true
      }
    });
  }
  initTestimonialSwiper();

  /*=============================================
      =        Team Social Active 	       =
  =============================================*/
  function initToggleSocial() {
    $(".social-toggle-icon").on("click", function () {
      $(this).parent().find("ul").slideToggle(400);
      $(this).find("i").toggleClass("fa-times");
      return false;
    });
  }
  initToggleSocial();
  function initSwitcherPricing() {
    $(".pricing__tab-switcher, .pricing__tab-btn").on("click", function () {
      $(".pricing__tab-switcher, .pricing__tab-btn").toggleClass("active"), $(".pricing__tab").toggleClass("seleceted"), $(".pricing__price").toggleClass("change-subs-duration");
    });
  }
  initSwitcherPricing();

  /*=============================================
      =    		Odometer Active  	       =
  =============================================*/
  function initCounter() {
    $(".odometer").appear(function (e) {
      var odo = $(".odometer");
      odo.each(function () {
        var countNumber = $(this).attr("data-count");
        $(this).html(countNumber);
      });
    });
  }
  initCounter();

  /*=============================================
      =    		Magnific Popup		      =
  =============================================*/
  $(".popup-image").magnificPopup({
    type: "image",
    gallery: {
      enabled: true
    }
  });

  /* magnificPopup video view */
  $(".popup-video").magnificPopup({
    type: "iframe"
  });

  /*=============================================
      =    		 Wow Active  	         =
  =============================================*/
  function wowAnimation() {
    var wow = new WOW({
      boxClass: "wow",
      animateClass: "animated",
      offset: 0,
      mobile: false,
      live: true
    });
    wow.init();
  }

  /*=============================================
      =           Aos Active       =
  =============================================*/
  function aosAnimation() {
    AOS.init({
      duration: 1000,
      mirror: true,
      once: true,
      disable: "mobile"
    });
  }
  $(".view-password").on("click", function () {
    var _parent = $(this).parent("div");
    var _input = _parent.find("input");
    if (_input.attr("type") === "password") {
      _input.attr("type", "text");
    } else {
      _input.attr("type", "password");
    }
  });
  $(window).resize(function () {
    var _container = $("main .container");
    var _window_w = $(window).width();
    var _container_w = _container.width();
    var _space = (_window_w - _container_w) / 2 - 15;
    var _form_quote = $(".slider__area-home8 .box-form-quote");
    _form_quote.css("right", "" + _space + "px");
  }).resize();
  function initSplitTextCircle() {
    var text = document.querySelector(".circle");
    if (text) {
      text.innerHTML = text.textContent.replace(/\S/g, "<span>$&</span>");
      var element = document.querySelectorAll(".circle span");
      for (var i = 0; i < element.length; i++) {
        element[i].style.transform = "rotate(" + i * 17 + "deg)";
      }
    }
  }
  initSplitTextCircle();
  document.addEventListener("shortcode.loaded", function (e) {
    var _e$detail = e.detail,
      name = _e$detail.name,
      attributes = _e$detail.attributes;
    switch (name) {
      case "site-statistics":
        initCounter();
        break;
      case "testimonials":
        initTestimonialSwiper();
        break;
      case "about-us-information":
        if (attributes.style === "style-1") {
          initSplitTextCircle();
        }
        break;
      case "brands":
        initBrandsSwiper();
        break;
      case "projects":
        if (["style-2", "style-4"].includes(attributes.style)) {
          initProjectsSwiper();
        }
        break;
      case "team":
        initToggleSocial();
        break;
      case "pricing":
        initSwitcherPricing();
        break;
    }
  });
  document.addEventListener("ecommerce.quick-shop.before-send", function (e) {
    $("#quick-shop-modal").find(".modal-body").append("<div class=\"loading-spinner\"></div>");
  });
  var footerBottom = $("#footer-bottom");
  var footerBottomInner = footerBottom.find(".bottom-footer-wrapper");
  if (footerBottomInner.children().length > 1) {
    footerBottomInner.removeClass("justify-content-center");
    footerBottomInner.addClass("justify-content-between");
  }
  var quotationRangePrice = $("#quotation-form-price");
  if (quotationRangePrice.length) {
    quotationRangePrice.on("change, mousemove", function (e) {
      $("#rangeValue").html(e.target.value);
      quotationRangePrice.val(e.target.value);
    });
  }
  var $announcementContainer = $(".ae-anno-announcement-wrapper");
  var $announcementData = $('[data-bb-toggle="announcement"]');
  if ($announcementContainer.length && $announcementData.length) {
    var getHeightAnnouncement = function getHeightAnnouncement() {
      var height = $announcementContainer.outerHeight() || 0;
      $($announcementData.data("bb-target")).css("--height-announcement", height + "px");
    };
    setTimeout(function () {
      getHeightAnnouncement();
    }, 500);
    $announcementContainer.on("click", ".ae-anno-announcement__arrow, .ae-anno-announcement__dismiss-button", function () {
      getHeightAnnouncement();
    });
    $(window).resize(function () {
      getHeightAnnouncement();
    });
  }
  $(document).on("click", ".btn-scroll-down", function (e) {
    e.preventDefault();
    var section = $(this).closest("section").nextAll("section").first();
    if (!section.length) {
      section = $("footer");
    }
    $("html, body").animate({
      scrollTop: section.offset().top
    }, 1000);
  });
  /*=============================================
      =          Swiper Ads Active              =
  =============================================*/
  // Swiper Ads   DỊCH VỤ GOOGLE ADS
  new Swiper(".category-pages", {
    loop: true,
    spaceBetween: 20,
    centeredSlides: true,
    slidesPerView: 3,
    autoplay: {
      delay: 3000,
      // ⏱ thời gian chờ giữa các slide (ms)
      disableOnInteraction: false,
      // ✅ vẫn chạy lại sau khi người dùng tương tác
      pauseOnMouseEnter: true // ✅ dừng khi hover chuột
    },
    pagination: {
      el: ".swiper-pagination",
      clickable: true
    },
    navigation: {
      nextEl: ".swiper-button-next",
      prevEl: ".swiper-button-prev"
    },
    breakpoints: {
      0: {
        slidesPerView: 1
      },
      768: {
        slidesPerView: 2
      },
      1024: {
        slidesPerView: 3
      }
    }
  });
  // TEAM TIVATECH
  new Swiper(".swiper-team", {
    loop: true,
    spaceBetween: 20,
    centeredSlides: false,
    slidesPerView: 4.2,
    autoplay: {
      delay: 3000,
      disableOnInteraction: false,
      pauseOnMouseEnter: true
    },
    pagination: {
      el: ".swiper-pagination",
      clickable: true
    },
    breakpoints: {
      0: {
        slidesPerView: 1.1,
        // ✅ hiện lấp ló slide tiếp theo
        centeredSlides: true
      },
      576: {
        slidesPerView: 1.3
      },
      768: {
        slidesPerView: 2
      },
      992: {
        slidesPerView: 3
      },
      1200: {
        slidesPerView: 4,
        centeredSlides: true
      }
    }
  });
  // DỊCH VỤ VỀ WEBSITE
  new Swiper(".swiper-services", {
    loop: true,
    spaceBetween: 24,
    slidesPerView: 3,
    centeredSlides: false,
    autoplay: {
      delay: 3000,
      disableOnInteraction: false,
      pauseOnMouseEnter: true
    },
    pagination: {
      el: ".swiper-pagination",
      clickable: true
    },
    navigation: {
      nextEl: ".swiper-button-next",
      prevEl: ".swiper-button-prev"
    },
    breakpoints: {
      0: {
        slidesPerView: 1
      },
      768: {
        slidesPerView: 2
      },
      1200: {
        slidesPerView: 3
      }
    }
  });
  // Vì sao chọn chúng tôi customer phần  website
  document.addEventListener("DOMContentLoaded", function () {
    var cards = document.querySelectorAll(".card-why-us");
    var secondCard = cards[1];
    secondCard.classList.add("active");
    cards.forEach(function (card) {
      card.addEventListener("mouseenter", function () {
        cards.forEach(function (c) {
          return c.classList.remove("active");
        });
      });
      card.addEventListener("mouseleave", function () {
        var isAnyHovered = Array.from(cards).some(function (c) {
          return c.matches(":hover");
        });
        if (!isAnyHovered) {
          secondCard.classList.add("active");
        }
      });
    });
  });

  // Js  cuả  quy trình làm việc tại Tivatech
  document.addEventListener("DOMContentLoaded", function () {
    var modalEl = document.getElementById("stepModal");
    var modalBody = document.getElementById("stepModalBody");

    // Click nút -> nạp content tương ứng
    document.querySelectorAll('[data-bs-target="#stepModal"]').forEach(function (btn) {
      btn.addEventListener("click", function () {
        var stepId = this.getAttribute("data-step-id"); // "step-0"
        var src = document.getElementById("content-" + stepId); // "content-step-0"
        modalBody.innerHTML = src ? src.innerHTML : "<p>Không có nội dung.</p>";
      });
    });

    // Dọn nội dung khi đóng modal
    modalEl.addEventListener("hidden.bs.modal", function () {
      modalBody.innerHTML = "";
    });
  });
  document.querySelectorAll(".shortcode-procedure-style2 .procedure-swiper").forEach(function (el) {
    var isMobileTablet = window.innerWidth < 1200;
    var swiper = new Swiper(el, {
      loop: isMobileTablet,
      // chỉ loop trên mobile/tablet
      spaceBetween: 24,
      slidesPerView: 3,
      centeredSlides: false,
      allowTouchMove: isMobileTablet,
      // chỉ cho kéo trên mobile/tablet
      pagination: {
        el: el.parentElement.querySelector(".swiper-pagination"),
        clickable: true
      },
      breakpoints: {
        0: {
          slidesPerView: 1
        },
        768: {
          slidesPerView: 2
        },
        1200: {
          slidesPerView: 6
        } // PC hiển thị hết timeline
      },
      observer: true,
      observeParents: true,
      updateOnWindowResize: true,
      autoplay: false // mặc định tắt autoplay
    });
    var steps = el.querySelectorAll(".step-item");
    var started = false;
    function activateStep(index) {
      steps.forEach(function (s) {
        return s.classList.remove("active");
      });
      if (steps[index]) {
        steps[index].classList.add("active");
      }
    }

    // luôn set bước 1 active ngay khi load
    activateStep(0);

    // Bắt đầu autoplay khi section vào viewport
    function startAutoRun() {
      if (started || steps.length === 0) return;
      started = true;
      if (isMobileTablet) {
        // Mobile & Tablet: autoplay swiper
        swiper.params.autoplay = {
          delay: 3000,
          // thời gian active = thời gian trượt
          disableOnInteraction: false
        };
        swiper.autoplay.start();

        // Sync active step khi slide thay đổi
        swiper.on("slideChange", function () {
          var realIndex = swiper.realIndex;
          activateStep(realIndex);
        });
      } else {
        // PC: interval tự chạy highlight
        var current = 0;
        activateStep(current);
        setInterval(function () {
          current = (current + 1) % steps.length;
          activateStep(current);
        }, 3000);
      }
    }

    // Observer để check khi section vào viewport
    var observer = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          startAutoRun();
        }
      });
    }, {
      threshold: 0.3
    });
    observer.observe(el);
  });
  // Dành riêng cho dự án website đã thực hiện tại tivatech
  document.querySelectorAll(".tiva-projec-swiper").forEach(function (el) {
    var swiper = new Swiper(el, {
      loop: false,
      spaceBetween: 24,
      centeredSlides: true,
      slidesPerView: 1,
      initialSlide: 2,
      // 🔥 mặc định vào item 3
      breakpoints: {
        768: {
          slidesPerView: 3
        },
        1200: {
          slidesPerView: 5
        }
      },
      pagination: {
        el: el.querySelector(".swiper-pagination"),
        clickable: true
      },
      navigation: {
        // 🔥 thêm navigation
        nextEl: el.querySelector(".swiper-button-next"),
        prevEl: el.querySelector(".swiper-button-prev")
      },
      slideToClickedSlide: true,
      grabCursor: true,
      watchSlidesProgress: true
    });
    // ---- PAN SETUP ----
    var SPEED = 250; // px/s → nhanh
    function computePan(img, wrap) {
      var containerH = wrap.clientHeight;
      var w = wrap.clientWidth;
      var naturalW = img.naturalWidth || w;
      var naturalH = img.naturalHeight || containerH;
      var displayedH = Math.round(w * (naturalH / naturalW));
      var overflow = displayedH - containerH;
      var panTo = overflow > 0 ? -overflow : 0;
      img.style.setProperty("--pan-to", panTo + "px");
      var dur = Math.max(1.2, Math.min(8, Math.abs(panTo) / SPEED));
      img.style.setProperty("--pan-duration", dur + "s");
    }
    function setupPans() {
      el.querySelectorAll(".tiva-project-icon").forEach(function (wrap) {
        var img = wrap.querySelector("img");
        if (!img) return;
        var run = function run() {
          return computePan(img, wrap);
        };
        img.complete ? run() : img.addEventListener("load", run);
        window.addEventListener("resize", run);
      });
    }
    setupPans();

    // ---- Hover ----
    el.querySelectorAll(".tiva-project-item").forEach(function (item) {
      var img = item.querySelector("img");
      item.addEventListener("mouseenter", function () {
        if (!img) return;
        img.classList.add("pan");
        item.classList.add("active");
      });
      item.addEventListener("mouseleave", function () {
        if (!img) return;
        img.classList.remove("pan");
        item.classList.remove("active");
      });
    });

    // ---- Click ----
    el.querySelectorAll(".swiper-slide").forEach(function (slide) {
      slide.addEventListener("click", function () {
        var index = Array.from(swiper.slides).indexOf(slide);
        if (index < 0) return;
        swiper.slideTo(index, 400); // nhảy vào giữa

        // reset cũ
        el.querySelectorAll(".tiva-project-item.active").forEach(function (item) {
          item.classList.remove("active");
          var img = item.querySelector("img");
          if (img) img.classList.remove("pan");
        });

        // pan ngay khi click
        var item = slide.querySelector(".tiva-project-item");
        var img = slide.querySelector(".tiva-project-icon img");
        if (item && img) {
          img.classList.add("pan");
          item.classList.add("active");
        }
      });
    });

    // ---- Khi slide đổi ----
    swiper.on("slideChangeTransitionStart", function () {
      el.querySelectorAll(".tiva-project-item.active").forEach(function (item) {
        item.classList.remove("active");
        var img = item.querySelector("img");
        if (img) img.classList.remove("pan");
      });
    });

    // ---- Khi khởi tạo: pan luôn item 3 ----
    swiper.on("init", function () {
      var activeSlide = swiper.slides[swiper.activeIndex];
      var item = activeSlide.querySelector(".tiva-project-item");
      var img = activeSlide.querySelector(".tiva-project-icon img");
      if (item && img) {
        img.classList.add("pan");
        item.classList.add("active");
      }
    });
    swiper.init();
  });
  document.addEventListener("DOMContentLoaded", function () {
    var gallery = document.getElementById("tiva-customer-reviews");
    if (gallery && window.lightGallery) {
      window.lightGallery(gallery, {
        selector: ".gallery-item",
        plugins: [lgThumbnail, lgZoom],
        speed: 500
      });
    }
  });
  document.addEventListener("DOMContentLoaded", function () {
    var gallery = document.getElementById("lightgallery");
    if (gallery && window.lightGallery) {
      window.lightGallery(gallery, {
        selector: ".gallery-item",
        plugins: [lgThumbnail, lgZoom],
        speed: 500
      });
    }
  });
  document.addEventListener("DOMContentLoaded", function () {
    var container = document.getElementById("tiva-review-grid");
    if (!container) return;
    var items = Array.from(container.querySelectorAll(".review-item"));
    var totalItems = items.length;
    var columns = 2; // default mobile
    var screenWidth = window.innerWidth;
    if (screenWidth >= 1200) {
      columns = 5;
    } else if (screenWidth >= 992) {
      columns = 4;
    } else if (screenWidth >= 768) {
      columns = 3;
    }

    // Reset container
    container.innerHTML = '';

    // Tạo columns
    var colEls = [];
    for (var i = 0; i < columns; i++) {
      var col = document.createElement('div');
      col.classList.add('review-col', i % 2 === 0 ? 'scroll-up' : 'scroll-down');
      container.appendChild(col);
      colEls.push(col);
    }

    // Gán từng ảnh vào cột tương ứng
    items.forEach(function (item, index) {
      colEls[index % columns].appendChild(item);
    });

    // 🔥 Nhân đôi nội dung mỗi cột để loop mượt
    colEls.forEach(function (col) {
      var clone = col.innerHTML;
      col.innerHTML += clone;
    });

    // LightGallery
    if (window.lightGallery) {
      window.lightGallery(container, {
        selector: '.gallery-item',
        plugins: [lgThumbnail, lgZoom],
        speed: 500
      });
    }
  });
})(jQuery);

/***/ }),

/***/ "./platform/themes/apexa/assets/sass/ecommerce.scss":
/*!**********************************************************!*\
  !*** ./platform/themes/apexa/assets/sass/ecommerce.scss ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/themes/apexa/assets/sass/style.scss":
/*!******************************************************!*\
  !*** ./platform/themes/apexa/assets/sass/style.scss ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./public/vendor/core/core/base/css/core.css":
/*!***************************************************!*\
  !*** ./public/vendor/core/core/base/css/core.css ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./public/vendor/core/core/base/css/libraries/select2.css":
/*!****************************************************************!*\
  !*** ./public/vendor/core/core/base/css/libraries/select2.css ***!
  \****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = __webpack_modules__;
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/chunk loaded */
/******/ 	(() => {
/******/ 		var deferred = [];
/******/ 		__webpack_require__.O = (result, chunkIds, fn, priority) => {
/******/ 			if(chunkIds) {
/******/ 				priority = priority || 0;
/******/ 				for(var i = deferred.length; i > 0 && deferred[i - 1][2] > priority; i--) deferred[i] = deferred[i - 1];
/******/ 				deferred[i] = [chunkIds, fn, priority];
/******/ 				return;
/******/ 			}
/******/ 			var notFulfilled = Infinity;
/******/ 			for (var i = 0; i < deferred.length; i++) {
/******/ 				var [chunkIds, fn, priority] = deferred[i];
/******/ 				var fulfilled = true;
/******/ 				for (var j = 0; j < chunkIds.length; j++) {
/******/ 					if ((priority & 1 === 0 || notFulfilled >= priority) && Object.keys(__webpack_require__.O).every((key) => (__webpack_require__.O[key](chunkIds[j])))) {
/******/ 						chunkIds.splice(j--, 1);
/******/ 					} else {
/******/ 						fulfilled = false;
/******/ 						if(priority < notFulfilled) notFulfilled = priority;
/******/ 					}
/******/ 				}
/******/ 				if(fulfilled) {
/******/ 					deferred.splice(i--, 1)
/******/ 					var r = fn();
/******/ 					if (r !== undefined) result = r;
/******/ 				}
/******/ 			}
/******/ 			return result;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/jsonp chunk loading */
/******/ 	(() => {
/******/ 		// no baseURI
/******/ 		
/******/ 		// object to store loaded and loading chunks
/******/ 		// undefined = chunk not loaded, null = chunk preloaded/prefetched
/******/ 		// [resolve, reject, Promise] = chunk loading, 0 = chunk loaded
/******/ 		var installedChunks = {
/******/ 			"/themes/apexa/js/main": 0,
/******/ 			"themes/apexa/css/style": 0,
/******/ 			"vendor/core/plugins/toc/css/toc": 0,
/******/ 			"vendor/core/plugins/translation/css/translation": 0,
/******/ 			"themes/apexa/css/ecommerce": 0,
/******/ 			"vendor/core/core/base/css/libraries/select2.rtl": 0,
/******/ 			"vendor/core/core/base/css/core.rtl": 0,
/******/ 			"vendor/core/core/base/css/crop-image": 0,
/******/ 			"vendor/core/core/base/css/tree-category": 0,
/******/ 			"vendor/core/core/base/css/error-pages": 0,
/******/ 			"vendor/core/core/base/css/libraries/select2": 0,
/******/ 			"vendor/core/core/base/css/core": 0,
/******/ 			"vendor/core/core/media/css/media": 0,
/******/ 			"vendor/core/core/setting/css/admin-email": 0,
/******/ 			"vendor/core/core/table/css/table": 0,
/******/ 			"vendor/core/packages/get-started/css/get-started": 0,
/******/ 			"vendor/core/packages/installer/css/style": 0,
/******/ 			"vendor/core/packages/menu/css/menu": 0,
/******/ 			"vendor/core/packages/revision/css/revision": 0,
/******/ 			"vendor/core/packages/seo-helper/css/seo-helper": 0,
/******/ 			"vendor/core/packages/shortcode/css/shortcode": 0,
/******/ 			"vendor/core/packages/slug/css/slug": 0,
/******/ 			"vendor/core/packages/theme/css/guideline": 0,
/******/ 			"vendor/core/packages/theme/css/admin-bar": 0,
/******/ 			"vendor/core/packages/theme/css/theme-options": 0,
/******/ 			"vendor/core/packages/widget/css/widget": 0,
/******/ 			"vendor/core/plugins/announcement/css/announcement": 0,
/******/ 			"vendor/core/plugins/backup/css/backup": 0,
/******/ 			"vendor/core/plugins/contact/css/contact-public": 0,
/******/ 			"vendor/core/plugins/contact/css/contact": 0,
/******/ 			"vendor/core/plugins/ecommerce/css/front-theme-rtl": 0,
/******/ 			"vendor/core/plugins/ecommerce/css/front-theme": 0,
/******/ 			"vendor/core/plugins/ecommerce/css/front-review": 0,
/******/ 			"vendor/core/plugins/ecommerce/css/front-faq": 0,
/******/ 			"vendor/core/plugins/ecommerce/css/front-ecommerce-rtl": 0,
/******/ 			"vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap": 0,
/******/ 			"vendor/core/plugins/ecommerce/css/front-ecommerce": 0,
/******/ 			"vendor/core/plugins/ecommerce/css/front-auth": 0,
/******/ 			"vendor/core/plugins/ecommerce/css/widget": 0,
/******/ 			"vendor/core/plugins/ecommerce/css/order-return": 0,
/******/ 			"vendor/core/plugins/ecommerce/css/report": 0,
/******/ 			"vendor/core/plugins/ecommerce/css/customer": 0,
/******/ 			"vendor/core/plugins/ecommerce/css/review": 0,
/******/ 			"vendor/core/plugins/ecommerce/css/currencies": 0,
/******/ 			"vendor/core/plugins/ecommerce/css/ecommerce-product-attributes": 0,
/******/ 			"vendor/core/plugins/ecommerce/css/ecommerce": 0,
/******/ 			"vendor/core/plugins/faq/css/faq": 0,
/******/ 			"vendor/core/plugins/fob-comment/css/comment": 0,
/******/ 			"vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons": 0,
/******/ 			"vendor/core/plugins/gallery/css/admin-gallery": 0,
/******/ 			"vendor/core/plugins/gallery/css/object-gallery": 0,
/******/ 			"vendor/core/plugins/gallery/css/gallery": 0,
/******/ 			"vendor/core/plugins/language/css/language-public": 0,
/******/ 			"vendor/core/plugins/language/css/language": 0,
/******/ 			"vendor/core/plugins/newsletter/css/newsletter": 0,
/******/ 			"vendor/core/plugins/payment/css/payment-setting": 0,
/******/ 			"vendor/core/plugins/payment/css/payment": 0,
/******/ 			"vendor/core/plugins/simple-slider/css/simple-slider": 0,
/******/ 			"vendor/core/plugins/social-login/css/social-login": 0,
/******/ 			"vendor/core/plugins/table-details-control/css/table": 0
/******/ 		};
/******/ 		
/******/ 		// no chunk on demand loading
/******/ 		
/******/ 		// no prefetching
/******/ 		
/******/ 		// no preloaded
/******/ 		
/******/ 		// no HMR
/******/ 		
/******/ 		// no HMR manifest
/******/ 		
/******/ 		__webpack_require__.O.j = (chunkId) => (installedChunks[chunkId] === 0);
/******/ 		
/******/ 		// install a JSONP callback for chunk loading
/******/ 		var webpackJsonpCallback = (parentChunkLoadingFunction, data) => {
/******/ 			var [chunkIds, moreModules, runtime] = data;
/******/ 			// add "moreModules" to the modules object,
/******/ 			// then flag all "chunkIds" as loaded and fire callback
/******/ 			var moduleId, chunkId, i = 0;
/******/ 			if(chunkIds.some((id) => (installedChunks[id] !== 0))) {
/******/ 				for(moduleId in moreModules) {
/******/ 					if(__webpack_require__.o(moreModules, moduleId)) {
/******/ 						__webpack_require__.m[moduleId] = moreModules[moduleId];
/******/ 					}
/******/ 				}
/******/ 				if(runtime) var result = runtime(__webpack_require__);
/******/ 			}
/******/ 			if(parentChunkLoadingFunction) parentChunkLoadingFunction(data);
/******/ 			for(;i < chunkIds.length; i++) {
/******/ 				chunkId = chunkIds[i];
/******/ 				if(__webpack_require__.o(installedChunks, chunkId) && installedChunks[chunkId]) {
/******/ 					installedChunks[chunkId][0]();
/******/ 				}
/******/ 				installedChunks[chunkId] = 0;
/******/ 			}
/******/ 			return __webpack_require__.O(result);
/******/ 		}
/******/ 		
/******/ 		var chunkLoadingGlobal = self["webpackChunk"] = self["webpackChunk"] || [];
/******/ 		chunkLoadingGlobal.forEach(webpackJsonpCallback.bind(null, 0));
/******/ 		chunkLoadingGlobal.push = webpackJsonpCallback.bind(null, chunkLoadingGlobal.push.bind(chunkLoadingGlobal));
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module depends on other loaded chunks and execution need to be delayed
/******/ 	__webpack_require__.O(undefined, ["themes/apexa/css/style","vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/apexa/css/ecommerce","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/announcement/css/announcement","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-comment/css/comment","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/gallery/css/admin-gallery","vendor/core/plugins/gallery/css/object-gallery","vendor/core/plugins/gallery/css/gallery","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login","vendor/core/plugins/table-details-control/css/table"], () => (__webpack_require__("./platform/themes/apexa/assets/js/main.js")))
/******/ 	__webpack_require__.O(undefined, ["themes/apexa/css/style","vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/apexa/css/ecommerce","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/announcement/css/announcement","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-comment/css/comment","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/gallery/css/admin-gallery","vendor/core/plugins/gallery/css/object-gallery","vendor/core/plugins/gallery/css/gallery","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login","vendor/core/plugins/table-details-control/css/table"], () => (__webpack_require__("./platform/themes/apexa/assets/sass/style.scss")))
/******/ 	__webpack_require__.O(undefined, ["themes/apexa/css/style","vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/apexa/css/ecommerce","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/announcement/css/announcement","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-comment/css/comment","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/gallery/css/admin-gallery","vendor/core/plugins/gallery/css/object-gallery","vendor/core/plugins/gallery/css/gallery","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login","vendor/core/plugins/table-details-control/css/table"], () => (__webpack_require__("./platform/themes/apexa/assets/sass/ecommerce.scss")))
/******/ 	__webpack_require__.O(undefined, ["themes/apexa/css/style","vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/apexa/css/ecommerce","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/announcement/css/announcement","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-comment/css/comment","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/gallery/css/admin-gallery","vendor/core/plugins/gallery/css/object-gallery","vendor/core/plugins/gallery/css/gallery","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login","vendor/core/plugins/table-details-control/css/table"], () => (__webpack_require__("./platform/plugins/translation/resources/sass/translation.scss")))
/******/ 	__webpack_require__.O(undefined, ["themes/apexa/css/style","vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/apexa/css/ecommerce","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/announcement/css/announcement","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-comment/css/comment","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/gallery/css/admin-gallery","vendor/core/plugins/gallery/css/object-gallery","vendor/core/plugins/gallery/css/gallery","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login","vendor/core/plugins/table-details-control/css/table"], () => (__webpack_require__("./platform/plugins/toc/resources/assets/sass/toc.scss")))
/******/ 	__webpack_require__.O(undefined, ["themes/apexa/css/style","vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/apexa/css/ecommerce","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/announcement/css/announcement","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-comment/css/comment","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/gallery/css/admin-gallery","vendor/core/plugins/gallery/css/object-gallery","vendor/core/plugins/gallery/css/gallery","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login","vendor/core/plugins/table-details-control/css/table"], () => (__webpack_require__("./platform/plugins/table-details-control/resources/sass/table.scss")))
/******/ 	__webpack_require__.O(undefined, ["themes/apexa/css/style","vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/apexa/css/ecommerce","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/announcement/css/announcement","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-comment/css/comment","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/gallery/css/admin-gallery","vendor/core/plugins/gallery/css/object-gallery","vendor/core/plugins/gallery/css/gallery","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login","vendor/core/plugins/table-details-control/css/table"], () => (__webpack_require__("./platform/plugins/social-login/resources/sass/social-login.scss")))
/******/ 	__webpack_require__.O(undefined, ["themes/apexa/css/style","vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/apexa/css/ecommerce","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/announcement/css/announcement","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-comment/css/comment","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/gallery/css/admin-gallery","vendor/core/plugins/gallery/css/object-gallery","vendor/core/plugins/gallery/css/gallery","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login","vendor/core/plugins/table-details-control/css/table"], () => (__webpack_require__("./platform/plugins/simple-slider/resources/sass/simple-slider.scss")))
/******/ 	__webpack_require__.O(undefined, ["themes/apexa/css/style","vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/apexa/css/ecommerce","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/announcement/css/announcement","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-comment/css/comment","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/gallery/css/admin-gallery","vendor/core/plugins/gallery/css/object-gallery","vendor/core/plugins/gallery/css/gallery","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login","vendor/core/plugins/table-details-control/css/table"], () => (__webpack_require__("./platform/plugins/payment/resources/sass/payment.scss")))
/******/ 	__webpack_require__.O(undefined, ["themes/apexa/css/style","vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/apexa/css/ecommerce","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/announcement/css/announcement","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-comment/css/comment","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/gallery/css/admin-gallery","vendor/core/plugins/gallery/css/object-gallery","vendor/core/plugins/gallery/css/gallery","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login","vendor/core/plugins/table-details-control/css/table"], () => (__webpack_require__("./platform/plugins/payment/resources/sass/payment-setting.scss")))
/******/ 	__webpack_require__.O(undefined, ["themes/apexa/css/style","vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/apexa/css/ecommerce","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/announcement/css/announcement","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-comment/css/comment","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/gallery/css/admin-gallery","vendor/core/plugins/gallery/css/object-gallery","vendor/core/plugins/gallery/css/gallery","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login","vendor/core/plugins/table-details-control/css/table"], () => (__webpack_require__("./platform/plugins/newsletter/resources/sass/newsletter.scss")))
/******/ 	__webpack_require__.O(undefined, ["themes/apexa/css/style","vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/apexa/css/ecommerce","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/announcement/css/announcement","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-comment/css/comment","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/gallery/css/admin-gallery","vendor/core/plugins/gallery/css/object-gallery","vendor/core/plugins/gallery/css/gallery","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login","vendor/core/plugins/table-details-control/css/table"], () => (__webpack_require__("./platform/plugins/language/resources/sass/language.scss")))
/******/ 	__webpack_require__.O(undefined, ["themes/apexa/css/style","vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/apexa/css/ecommerce","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/announcement/css/announcement","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-comment/css/comment","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/gallery/css/admin-gallery","vendor/core/plugins/gallery/css/object-gallery","vendor/core/plugins/gallery/css/gallery","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login","vendor/core/plugins/table-details-control/css/table"], () => (__webpack_require__("./platform/plugins/language/resources/sass/language-public.scss")))
/******/ 	__webpack_require__.O(undefined, ["themes/apexa/css/style","vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/apexa/css/ecommerce","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/announcement/css/announcement","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-comment/css/comment","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/gallery/css/admin-gallery","vendor/core/plugins/gallery/css/object-gallery","vendor/core/plugins/gallery/css/gallery","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login","vendor/core/plugins/table-details-control/css/table"], () => (__webpack_require__("./platform/plugins/gallery/resources/sass/gallery.scss")))
/******/ 	__webpack_require__.O(undefined, ["themes/apexa/css/style","vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/apexa/css/ecommerce","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/announcement/css/announcement","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-comment/css/comment","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/gallery/css/admin-gallery","vendor/core/plugins/gallery/css/object-gallery","vendor/core/plugins/gallery/css/gallery","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login","vendor/core/plugins/table-details-control/css/table"], () => (__webpack_require__("./platform/plugins/gallery/resources/sass/object-gallery.scss")))
/******/ 	__webpack_require__.O(undefined, ["themes/apexa/css/style","vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/apexa/css/ecommerce","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/announcement/css/announcement","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-comment/css/comment","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/gallery/css/admin-gallery","vendor/core/plugins/gallery/css/object-gallery","vendor/core/plugins/gallery/css/gallery","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login","vendor/core/plugins/table-details-control/css/table"], () => (__webpack_require__("./platform/plugins/gallery/resources/sass/admin-gallery.scss")))
/******/ 	__webpack_require__.O(undefined, ["themes/apexa/css/style","vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/apexa/css/ecommerce","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/announcement/css/announcement","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-comment/css/comment","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/gallery/css/admin-gallery","vendor/core/plugins/gallery/css/object-gallery","vendor/core/plugins/gallery/css/gallery","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login","vendor/core/plugins/table-details-control/css/table"], () => (__webpack_require__("./platform/plugins/fob-floating-buttons/resources/sass/fob-floating-buttons.scss")))
/******/ 	__webpack_require__.O(undefined, ["themes/apexa/css/style","vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/apexa/css/ecommerce","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/announcement/css/announcement","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-comment/css/comment","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/gallery/css/admin-gallery","vendor/core/plugins/gallery/css/object-gallery","vendor/core/plugins/gallery/css/gallery","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login","vendor/core/plugins/table-details-control/css/table"], () => (__webpack_require__("./platform/plugins/fob-comment/resources/sass/comment.scss")))
/******/ 	__webpack_require__.O(undefined, ["themes/apexa/css/style","vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/apexa/css/ecommerce","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/announcement/css/announcement","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-comment/css/comment","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/gallery/css/admin-gallery","vendor/core/plugins/gallery/css/object-gallery","vendor/core/plugins/gallery/css/gallery","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login","vendor/core/plugins/table-details-control/css/table"], () => (__webpack_require__("./platform/plugins/faq/resources/sass/faq.scss")))
/******/ 	__webpack_require__.O(undefined, ["themes/apexa/css/style","vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/apexa/css/ecommerce","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/announcement/css/announcement","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-comment/css/comment","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/gallery/css/admin-gallery","vendor/core/plugins/gallery/css/object-gallery","vendor/core/plugins/gallery/css/gallery","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login","vendor/core/plugins/table-details-control/css/table"], () => (__webpack_require__("./platform/plugins/ecommerce/resources/sass/ecommerce.scss")))
/******/ 	__webpack_require__.O(undefined, ["themes/apexa/css/style","vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/apexa/css/ecommerce","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/announcement/css/announcement","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-comment/css/comment","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/gallery/css/admin-gallery","vendor/core/plugins/gallery/css/object-gallery","vendor/core/plugins/gallery/css/gallery","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login","vendor/core/plugins/table-details-control/css/table"], () => (__webpack_require__("./platform/plugins/ecommerce/resources/sass/ecommerce-product-attributes.scss")))
/******/ 	__webpack_require__.O(undefined, ["themes/apexa/css/style","vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/apexa/css/ecommerce","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/announcement/css/announcement","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-comment/css/comment","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/gallery/css/admin-gallery","vendor/core/plugins/gallery/css/object-gallery","vendor/core/plugins/gallery/css/gallery","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login","vendor/core/plugins/table-details-control/css/table"], () => (__webpack_require__("./platform/plugins/ecommerce/resources/sass/currencies.scss")))
/******/ 	__webpack_require__.O(undefined, ["themes/apexa/css/style","vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/apexa/css/ecommerce","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/announcement/css/announcement","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-comment/css/comment","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/gallery/css/admin-gallery","vendor/core/plugins/gallery/css/object-gallery","vendor/core/plugins/gallery/css/gallery","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login","vendor/core/plugins/table-details-control/css/table"], () => (__webpack_require__("./platform/plugins/ecommerce/resources/sass/review.scss")))
/******/ 	__webpack_require__.O(undefined, ["themes/apexa/css/style","vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/apexa/css/ecommerce","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/announcement/css/announcement","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-comment/css/comment","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/gallery/css/admin-gallery","vendor/core/plugins/gallery/css/object-gallery","vendor/core/plugins/gallery/css/gallery","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login","vendor/core/plugins/table-details-control/css/table"], () => (__webpack_require__("./platform/plugins/ecommerce/resources/sass/customer.scss")))
/******/ 	__webpack_require__.O(undefined, ["themes/apexa/css/style","vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/apexa/css/ecommerce","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/announcement/css/announcement","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-comment/css/comment","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/gallery/css/admin-gallery","vendor/core/plugins/gallery/css/object-gallery","vendor/core/plugins/gallery/css/gallery","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login","vendor/core/plugins/table-details-control/css/table"], () => (__webpack_require__("./platform/plugins/ecommerce/resources/sass/report.scss")))
/******/ 	__webpack_require__.O(undefined, ["themes/apexa/css/style","vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/apexa/css/ecommerce","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/announcement/css/announcement","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-comment/css/comment","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/gallery/css/admin-gallery","vendor/core/plugins/gallery/css/object-gallery","vendor/core/plugins/gallery/css/gallery","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login","vendor/core/plugins/table-details-control/css/table"], () => (__webpack_require__("./platform/plugins/ecommerce/resources/sass/order-return.scss")))
/******/ 	__webpack_require__.O(undefined, ["themes/apexa/css/style","vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/apexa/css/ecommerce","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/announcement/css/announcement","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-comment/css/comment","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/gallery/css/admin-gallery","vendor/core/plugins/gallery/css/object-gallery","vendor/core/plugins/gallery/css/gallery","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login","vendor/core/plugins/table-details-control/css/table"], () => (__webpack_require__("./platform/plugins/ecommerce/resources/sass/widget.scss")))
/******/ 	__webpack_require__.O(undefined, ["themes/apexa/css/style","vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/apexa/css/ecommerce","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/announcement/css/announcement","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-comment/css/comment","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/gallery/css/admin-gallery","vendor/core/plugins/gallery/css/object-gallery","vendor/core/plugins/gallery/css/gallery","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login","vendor/core/plugins/table-details-control/css/table"], () => (__webpack_require__("./platform/plugins/ecommerce/resources/sass/front-auth.scss")))
/******/ 	__webpack_require__.O(undefined, ["themes/apexa/css/style","vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/apexa/css/ecommerce","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/announcement/css/announcement","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-comment/css/comment","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/gallery/css/admin-gallery","vendor/core/plugins/gallery/css/object-gallery","vendor/core/plugins/gallery/css/gallery","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login","vendor/core/plugins/table-details-control/css/table"], () => (__webpack_require__("./platform/plugins/ecommerce/resources/sass/front-ecommerce.scss")))
/******/ 	__webpack_require__.O(undefined, ["themes/apexa/css/style","vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/apexa/css/ecommerce","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/announcement/css/announcement","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-comment/css/comment","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/gallery/css/admin-gallery","vendor/core/plugins/gallery/css/object-gallery","vendor/core/plugins/gallery/css/gallery","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login","vendor/core/plugins/table-details-control/css/table"], () => (__webpack_require__("./platform/plugins/ecommerce/resources/sass/front-ecommerce-missing-bootstrap.scss")))
/******/ 	__webpack_require__.O(undefined, ["themes/apexa/css/style","vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/apexa/css/ecommerce","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/announcement/css/announcement","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-comment/css/comment","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/gallery/css/admin-gallery","vendor/core/plugins/gallery/css/object-gallery","vendor/core/plugins/gallery/css/gallery","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login","vendor/core/plugins/table-details-control/css/table"], () => (__webpack_require__("./platform/plugins/ecommerce/resources/sass/front-ecommerce-rtl.scss")))
/******/ 	__webpack_require__.O(undefined, ["themes/apexa/css/style","vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/apexa/css/ecommerce","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/announcement/css/announcement","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-comment/css/comment","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/gallery/css/admin-gallery","vendor/core/plugins/gallery/css/object-gallery","vendor/core/plugins/gallery/css/gallery","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login","vendor/core/plugins/table-details-control/css/table"], () => (__webpack_require__("./platform/plugins/ecommerce/resources/sass/front-faq.scss")))
/******/ 	__webpack_require__.O(undefined, ["themes/apexa/css/style","vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/apexa/css/ecommerce","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/announcement/css/announcement","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-comment/css/comment","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/gallery/css/admin-gallery","vendor/core/plugins/gallery/css/object-gallery","vendor/core/plugins/gallery/css/gallery","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login","vendor/core/plugins/table-details-control/css/table"], () => (__webpack_require__("./platform/plugins/ecommerce/resources/sass/front-review.scss")))
/******/ 	__webpack_require__.O(undefined, ["themes/apexa/css/style","vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/apexa/css/ecommerce","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/announcement/css/announcement","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-comment/css/comment","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/gallery/css/admin-gallery","vendor/core/plugins/gallery/css/object-gallery","vendor/core/plugins/gallery/css/gallery","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login","vendor/core/plugins/table-details-control/css/table"], () => (__webpack_require__("./platform/plugins/ecommerce/resources/sass/front-theme.scss")))
/******/ 	__webpack_require__.O(undefined, ["themes/apexa/css/style","vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/apexa/css/ecommerce","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/announcement/css/announcement","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-comment/css/comment","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/gallery/css/admin-gallery","vendor/core/plugins/gallery/css/object-gallery","vendor/core/plugins/gallery/css/gallery","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login","vendor/core/plugins/table-details-control/css/table"], () => (__webpack_require__("./platform/plugins/ecommerce/resources/sass/front-theme-rtl.scss")))
/******/ 	__webpack_require__.O(undefined, ["themes/apexa/css/style","vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/apexa/css/ecommerce","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/announcement/css/announcement","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-comment/css/comment","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/gallery/css/admin-gallery","vendor/core/plugins/gallery/css/object-gallery","vendor/core/plugins/gallery/css/gallery","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login","vendor/core/plugins/table-details-control/css/table"], () => (__webpack_require__("./platform/plugins/contact/resources/sass/contact.scss")))
/******/ 	__webpack_require__.O(undefined, ["themes/apexa/css/style","vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/apexa/css/ecommerce","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/announcement/css/announcement","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-comment/css/comment","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/gallery/css/admin-gallery","vendor/core/plugins/gallery/css/object-gallery","vendor/core/plugins/gallery/css/gallery","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login","vendor/core/plugins/table-details-control/css/table"], () => (__webpack_require__("./platform/plugins/contact/resources/sass/contact-public.scss")))
/******/ 	__webpack_require__.O(undefined, ["themes/apexa/css/style","vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/apexa/css/ecommerce","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/announcement/css/announcement","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-comment/css/comment","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/gallery/css/admin-gallery","vendor/core/plugins/gallery/css/object-gallery","vendor/core/plugins/gallery/css/gallery","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login","vendor/core/plugins/table-details-control/css/table"], () => (__webpack_require__("./platform/plugins/backup/resources/sass/backup.scss")))
/******/ 	__webpack_require__.O(undefined, ["themes/apexa/css/style","vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/apexa/css/ecommerce","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/announcement/css/announcement","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-comment/css/comment","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/gallery/css/admin-gallery","vendor/core/plugins/gallery/css/object-gallery","vendor/core/plugins/gallery/css/gallery","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login","vendor/core/plugins/table-details-control/css/table"], () => (__webpack_require__("./platform/plugins/announcement/resources/sass/announcement.scss")))
/******/ 	__webpack_require__.O(undefined, ["themes/apexa/css/style","vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/apexa/css/ecommerce","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/announcement/css/announcement","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-comment/css/comment","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/gallery/css/admin-gallery","vendor/core/plugins/gallery/css/object-gallery","vendor/core/plugins/gallery/css/gallery","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login","vendor/core/plugins/table-details-control/css/table"], () => (__webpack_require__("./platform/packages/widget/resources/sass/widget.scss")))
/******/ 	__webpack_require__.O(undefined, ["themes/apexa/css/style","vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/apexa/css/ecommerce","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/announcement/css/announcement","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-comment/css/comment","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/gallery/css/admin-gallery","vendor/core/plugins/gallery/css/object-gallery","vendor/core/plugins/gallery/css/gallery","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login","vendor/core/plugins/table-details-control/css/table"], () => (__webpack_require__("./platform/packages/theme/resources/sass/theme-options.scss")))
/******/ 	__webpack_require__.O(undefined, ["themes/apexa/css/style","vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/apexa/css/ecommerce","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/announcement/css/announcement","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-comment/css/comment","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/gallery/css/admin-gallery","vendor/core/plugins/gallery/css/object-gallery","vendor/core/plugins/gallery/css/gallery","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login","vendor/core/plugins/table-details-control/css/table"], () => (__webpack_require__("./platform/packages/theme/resources/sass/admin-bar.scss")))
/******/ 	__webpack_require__.O(undefined, ["themes/apexa/css/style","vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/apexa/css/ecommerce","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/announcement/css/announcement","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-comment/css/comment","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/gallery/css/admin-gallery","vendor/core/plugins/gallery/css/object-gallery","vendor/core/plugins/gallery/css/gallery","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login","vendor/core/plugins/table-details-control/css/table"], () => (__webpack_require__("./platform/packages/theme/resources/sass/guideline.scss")))
/******/ 	__webpack_require__.O(undefined, ["themes/apexa/css/style","vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/apexa/css/ecommerce","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/announcement/css/announcement","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-comment/css/comment","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/gallery/css/admin-gallery","vendor/core/plugins/gallery/css/object-gallery","vendor/core/plugins/gallery/css/gallery","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login","vendor/core/plugins/table-details-control/css/table"], () => (__webpack_require__("./platform/packages/slug/resources/sass/slug.scss")))
/******/ 	__webpack_require__.O(undefined, ["themes/apexa/css/style","vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/apexa/css/ecommerce","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/announcement/css/announcement","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-comment/css/comment","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/gallery/css/admin-gallery","vendor/core/plugins/gallery/css/object-gallery","vendor/core/plugins/gallery/css/gallery","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login","vendor/core/plugins/table-details-control/css/table"], () => (__webpack_require__("./platform/packages/shortcode/resources/sass/shortcode.scss")))
/******/ 	__webpack_require__.O(undefined, ["themes/apexa/css/style","vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/apexa/css/ecommerce","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/announcement/css/announcement","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-comment/css/comment","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/gallery/css/admin-gallery","vendor/core/plugins/gallery/css/object-gallery","vendor/core/plugins/gallery/css/gallery","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login","vendor/core/plugins/table-details-control/css/table"], () => (__webpack_require__("./platform/packages/seo-helper/resources/sass/seo-helper.scss")))
/******/ 	__webpack_require__.O(undefined, ["themes/apexa/css/style","vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/apexa/css/ecommerce","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/announcement/css/announcement","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-comment/css/comment","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/gallery/css/admin-gallery","vendor/core/plugins/gallery/css/object-gallery","vendor/core/plugins/gallery/css/gallery","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login","vendor/core/plugins/table-details-control/css/table"], () => (__webpack_require__("./platform/packages/revision/resources/sass/revision.scss")))
/******/ 	__webpack_require__.O(undefined, ["themes/apexa/css/style","vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/apexa/css/ecommerce","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/announcement/css/announcement","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-comment/css/comment","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/gallery/css/admin-gallery","vendor/core/plugins/gallery/css/object-gallery","vendor/core/plugins/gallery/css/gallery","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login","vendor/core/plugins/table-details-control/css/table"], () => (__webpack_require__("./platform/packages/menu/resources/sass/menu.scss")))
/******/ 	__webpack_require__.O(undefined, ["themes/apexa/css/style","vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/apexa/css/ecommerce","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/announcement/css/announcement","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-comment/css/comment","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/gallery/css/admin-gallery","vendor/core/plugins/gallery/css/object-gallery","vendor/core/plugins/gallery/css/gallery","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login","vendor/core/plugins/table-details-control/css/table"], () => (__webpack_require__("./platform/packages/installer/resources/sass/style.scss")))
/******/ 	__webpack_require__.O(undefined, ["themes/apexa/css/style","vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/apexa/css/ecommerce","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/announcement/css/announcement","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-comment/css/comment","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/gallery/css/admin-gallery","vendor/core/plugins/gallery/css/object-gallery","vendor/core/plugins/gallery/css/gallery","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login","vendor/core/plugins/table-details-control/css/table"], () => (__webpack_require__("./platform/packages/get-started/resources/sass/get-started.scss")))
/******/ 	__webpack_require__.O(undefined, ["themes/apexa/css/style","vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/apexa/css/ecommerce","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/announcement/css/announcement","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-comment/css/comment","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/gallery/css/admin-gallery","vendor/core/plugins/gallery/css/object-gallery","vendor/core/plugins/gallery/css/gallery","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login","vendor/core/plugins/table-details-control/css/table"], () => (__webpack_require__("./platform/core/table/resources/sass/table.scss")))
/******/ 	__webpack_require__.O(undefined, ["themes/apexa/css/style","vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/apexa/css/ecommerce","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/announcement/css/announcement","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-comment/css/comment","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/gallery/css/admin-gallery","vendor/core/plugins/gallery/css/object-gallery","vendor/core/plugins/gallery/css/gallery","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login","vendor/core/plugins/table-details-control/css/table"], () => (__webpack_require__("./platform/core/setting/resources/sass/admin-email.scss")))
/******/ 	__webpack_require__.O(undefined, ["themes/apexa/css/style","vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/apexa/css/ecommerce","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/announcement/css/announcement","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-comment/css/comment","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/gallery/css/admin-gallery","vendor/core/plugins/gallery/css/object-gallery","vendor/core/plugins/gallery/css/gallery","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login","vendor/core/plugins/table-details-control/css/table"], () => (__webpack_require__("./platform/core/media/resources/sass/media.scss")))
/******/ 	__webpack_require__.O(undefined, ["themes/apexa/css/style","vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/apexa/css/ecommerce","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/announcement/css/announcement","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-comment/css/comment","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/gallery/css/admin-gallery","vendor/core/plugins/gallery/css/object-gallery","vendor/core/plugins/gallery/css/gallery","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login","vendor/core/plugins/table-details-control/css/table"], () => (__webpack_require__("./platform/core/base/resources/sass/core.scss")))
/******/ 	__webpack_require__.O(undefined, ["themes/apexa/css/style","vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/apexa/css/ecommerce","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/announcement/css/announcement","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-comment/css/comment","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/gallery/css/admin-gallery","vendor/core/plugins/gallery/css/object-gallery","vendor/core/plugins/gallery/css/gallery","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login","vendor/core/plugins/table-details-control/css/table"], () => (__webpack_require__("./platform/core/base/resources/sass/libraries/select2/select2.scss")))
/******/ 	__webpack_require__.O(undefined, ["themes/apexa/css/style","vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/apexa/css/ecommerce","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/announcement/css/announcement","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-comment/css/comment","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/gallery/css/admin-gallery","vendor/core/plugins/gallery/css/object-gallery","vendor/core/plugins/gallery/css/gallery","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login","vendor/core/plugins/table-details-control/css/table"], () => (__webpack_require__("./platform/core/base/resources/sass/components/error-pages.scss")))
/******/ 	__webpack_require__.O(undefined, ["themes/apexa/css/style","vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/apexa/css/ecommerce","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/announcement/css/announcement","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-comment/css/comment","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/gallery/css/admin-gallery","vendor/core/plugins/gallery/css/object-gallery","vendor/core/plugins/gallery/css/gallery","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login","vendor/core/plugins/table-details-control/css/table"], () => (__webpack_require__("./platform/core/base/resources/sass/components/tree-category.scss")))
/******/ 	__webpack_require__.O(undefined, ["themes/apexa/css/style","vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/apexa/css/ecommerce","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/announcement/css/announcement","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-comment/css/comment","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/gallery/css/admin-gallery","vendor/core/plugins/gallery/css/object-gallery","vendor/core/plugins/gallery/css/gallery","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login","vendor/core/plugins/table-details-control/css/table"], () => (__webpack_require__("./platform/core/base/resources/sass/components/crop-image.scss")))
/******/ 	__webpack_require__.O(undefined, ["themes/apexa/css/style","vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/apexa/css/ecommerce","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/announcement/css/announcement","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-comment/css/comment","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/gallery/css/admin-gallery","vendor/core/plugins/gallery/css/object-gallery","vendor/core/plugins/gallery/css/gallery","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login","vendor/core/plugins/table-details-control/css/table"], () => (__webpack_require__("./public/vendor/core/core/base/css/core.css")))
/******/ 	var __webpack_exports__ = __webpack_require__.O(undefined, ["themes/apexa/css/style","vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/apexa/css/ecommerce","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/announcement/css/announcement","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-comment/css/comment","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/gallery/css/admin-gallery","vendor/core/plugins/gallery/css/object-gallery","vendor/core/plugins/gallery/css/gallery","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login","vendor/core/plugins/table-details-control/css/table"], () => (__webpack_require__("./public/vendor/core/core/base/css/libraries/select2.css")))
/******/ 	__webpack_exports__ = __webpack_require__.O(__webpack_exports__);
/******/ 	
/******/ })()
;